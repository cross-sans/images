from textEngine import gml #the main file from the text engine project

gameEngine = gml.Engine("game test",True)