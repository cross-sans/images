import sys
import os
import requests
import zipfile

class Engine:
    def __init__(self, name, inventory=False, colored=False, version="0.0.1"):
        self.inventory = inventory
        self.colored = colored
        self.version = version
        self.name = name
        self.setup()

    def setup(self):
        print(f"Thanks for downloading {self.name} version {self.version}!")

        if self.inventory:
            self.inv = []
            print("Inventory created. >o<")
        elif not self.inventory:
            print("Inventory is not enabled in this game. :(")
            return

        if self.colored:
            #colored text
            pass
    
    def addToInv(self,thing):
        self.inv.append(thing)
    
    def removeFromInv(self,thing):
        try:
            self.inv.remove(thing)
        except:
            print(f"{thing} is not in inventory")
    
    def getUpdate(self, url, auto=True):
        if auto:
            print("Checking for updates...")
            # Make a request to the URL to check for an update
            response = requests.get(url + "/version.txt")
            latest_version = response.text.strip()

            if latest_version != self.version:
                print(f"An update is available! (version {latest_version})")
                choice = input("Do you want to update? (y/n): ")
                if choice.lower() == 'y':
                    self._update(url)
                else:
                    print("Skipping update.")
            else:
                print("You have the latest version!")
        else:
            self._update(url)
    
    def _update(self, url):
        print("Downloading update...")
        # Download the zip file
        response = requests.get(url + "/update.zip")
        zip_file = response.content

        # Save the zip file to disk
        with open('update.zip', 'wb') as f:
            f.write(zip_file)

        # Unzip the contents of the file
        with zipfile.ZipFile('update.zip', 'r') as zip_ref:
            zip_ref.extractall('.')

        # Remove the zip file
        os.remove('update.zip')

        # Update the version number
        with open('version.txt', 'w') as f:
            f.write(self.version)

        print("Update complete! Please restart the game.")
